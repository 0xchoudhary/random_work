|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |  1150 | daffainfo     |   560 | cves             |  1154 | info     |  1183 | http    |  3164 |
| panel     |   513 | dhiyaneshdk   |   421 | exposed-panels   |   519 | high     |   870 | file    |    68 |
| lfi       |   460 | pikpikcu      |   316 | vulnerabilities  |   446 | medium   |   658 | network |    50 |
| xss       |   363 | pdteam        |   262 | technologies     |   251 | critical |   411 | dns     |    17 |
| wordpress |   358 | geeknik       |   178 | exposures        |   203 | low      |   180 |         |       |
| exposure  |   292 | dwisiswant0   |   168 | misconfiguration |   196 | unknown  |     6 |         |       |
| rce       |   289 | princechaddha |   130 | workflows        |   186 |          |       |         |       |
| cve2021   |   283 | 0x_akoko      |   129 | token-spray      |   153 |          |       |         |       |
| tech      |   265 | gy741         |   117 | default-logins   |    95 |          |       |         |       |
| wp-plugin |   259 | pussycat0x    |   116 | file             |    68 |          |       |         |       |
